from django.contrib import admin
from .models import NoteModel

# Register your models here.
admin.site.register(NoteModel)
